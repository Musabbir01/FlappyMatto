package FlappyMatto;

/**
 * Created by admin on 12/10/2017.
 */
public class FlappyMatto {
    public static void main(String[] args) {
        Matto matto=new Matto("Flappy MattoImage",540,700);
        matto.start();

    }
}
